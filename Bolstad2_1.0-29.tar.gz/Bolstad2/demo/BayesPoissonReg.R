data(poissonTest.df)
BayesPois(poissonTest.df$y, poissonTest.df$x, plots = T)

